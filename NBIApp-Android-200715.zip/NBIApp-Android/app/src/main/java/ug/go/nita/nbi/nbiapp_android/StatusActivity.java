package ug.go.nita.nbi.nbiapp_android;

import android.content.Entity;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
//

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class StatusActivity extends ActionBarActivity {

    /** Called when the activity is first created. */
    private static String SOAP_ACTION1 = "http://tempuri.org/getStatus";
   // private static String SOAP_ACTION2 = "http://tempuri.org/CelsiusToFahrenheit";
    private static String NAMESPACE = "http://tempuri.org/";
    private static String METHOD_NAME1 = "getStatus";
  //  private static String METHOD_NAME2 = "CelsiusToFahrenheit";
    private static String URL = "http://aspspider.ws/osbertosamai/Service1.asmx?WSDL";
    //
   // SimpleAdapter adapter;
    StringBuilder htmlString = new StringBuilder();
    //
    String editText;
    String displayText;
    Button btnFar,btnPost;
    EditText txtFar,txtCel;
    ProgressBar pg;

    //added
    private ArrayList<String> list;
    private ListView listview;
    private ArrayAdapter<String> adapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status);
//

        btnFar = (Button)findViewById(R.id.btnFar);
       // txtFar = (EditText)findViewById(R.id.txtFar);
        //txtCel = (EditText)findViewById(R.id.txtCel);
btnPost  = (Button)findViewById(R.id.btnPost);

        btnFar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {


                    //Create instance for AsyncCallWS
                    AsyncCallWS task = new AsyncCallWS();
                    //Call execute
                    task.execute();
                    //If text control is empty



            }
        });

        //Post button
        btnPost.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {


               // Start Post Activity

                Intent intent = new Intent(StatusActivity.this, PostActivity.class);
                StatusActivity.this.startActivity(intent);

            }
        });


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_status, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private class AsyncCallWS extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            //
            //Initialize soap request + add parameters
            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME1);

            //Use this to add parameters
            request.addProperty("id","1");

            //Declare the version of the SOAP request
            SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
           envelope.setOutputSoapObject(request);



            try {
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);

                //this is the actual part that will call the webservice
                androidHttpTransport.debug = true;
                androidHttpTransport.call(SOAP_ACTION1, envelope);

                // Get the SoapResult from the envelope body.
                SoapObject result = (SoapObject)envelope.bodyIn;

                //new


                //xml
                String xml = androidHttpTransport.responseDump;

                if(result != null)
                {
                    //Get the first property and change the label text
                   // txtCel.setText(result.getProperty(0).toString());
                    displayText = xml;

                    //parse xml

                    StringReader reader = new StringReader(displayText);

                    CountryXmlParser countryXmlParser = new CountryXmlParser();

                    List<HashMap<String, String>> countries = null;

                    try{
                        /** Getting the parsed data as a List construct */
                        countries = countryXmlParser.parse(reader);
                        //
                        for (HashMap entry : countries) {

                            htmlString.append(entry.get("details"));

                        }
                    }catch(Exception e){
                        Log.d("Exception",e.toString());
                    }

                    /** Keys used in Hashmap */
                  //  String[] from = { "details"};

                    /** Ids of views in listview_layout */
                    //int[] to = { R.id.lv_countries};

                    /** Instantiating an adapter to store each items
                     *  R.layout.listview_layout defines the layout of each item
                     */
                  //  SimpleAdapter adapter = new SimpleAdapter(getBaseContext(), countries, R.layout.activity_status, from, to);

                    return htmlString.toString();



                }
                else
                {
                    Toast.makeText(getApplicationContext(), "No Response",Toast.LENGTH_LONG).show();
                }

                //Invoke webservice


                //
            } catch (Exception e) {
                e.printStackTrace();
            }
            return htmlString.toString();

        }

        @Override
        protected void onPostExecute( String Str) {
            //Set response
          // txtCel.setText(displayText);
            //Make ProgressBar invisible

          //  progressDialog.dismiss();

            setContentView(R.layout.activity_status);
            // Displays the HTML string in the UI via a WebView
            WebView myWebView = (WebView) findViewById(R.id.webView);
            myWebView.loadData(Str, "text/html", null);

        }

        @Override
        protected void onPreExecute() {
            //Make ProgressBar invisible
          //  pg.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }

    }

}
