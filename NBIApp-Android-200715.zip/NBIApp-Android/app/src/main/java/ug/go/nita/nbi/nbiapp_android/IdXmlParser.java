package ug.go.nita.nbi.nbiapp_android;

import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Osbert.Osamai on 7/17/2015.
 */
public class IdXmlParser {
    private static final String ns = null;

    /** This is the only function need to be called from outside the class */
    public List<HashMap<String, String>> parse(Reader reader)
            throws XmlPullParserException, IOException{
        try{
            XmlPullParser parser = Xml.newPullParser();
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(reader);
            parser.nextTag();
            return readCountries(parser);
        }finally{
        }
    }

    /** This method read each country in the xml data and add it to List */
    private List<HashMap<String, String>> readCountries(XmlPullParser parser)
            throws XmlPullParserException,IOException{

        List<HashMap<String, String>> list = new ArrayList<HashMap<String,String>>();

      // parser.require(XmlPullParser.START_TAG, ns, "soap:Envelope");

        while(parser.next() != XmlPullParser.END_TAG){
            if(parser.getEventType() != XmlPullParser.START_TAG){
                continue;
            }

            String name = parser.getName();
            if(name.equals("postIssueResult")){
                list.add(readCountry(parser));
            }
           /* else{
                skip(parser);
            }*/
        }
        return list;
    }

    /** This method read a country and returns its corresponding HashMap construct */
    private HashMap<String, String> readCountry(XmlPullParser parser)
            throws XmlPullParserException, IOException{

        parser.require(XmlPullParser.START_TAG, ns, "postIssueResult");

        String issueid = "";



        while(parser.next() != XmlPullParser.END_TAG){
            if(parser.getEventType() != XmlPullParser.START_TAG){
                continue;
            }

            String name = parser.getName();

            if(name.equals("root")){
               issueid = readIssueid(parser);
            }
            else{
                skip(parser);
            }
        }

        String details =  "<h2>"+"<font color=YellowGreen>"+ "Issue Successfully Posted with ID "+"</font>"+" "+"<em>" + issueid +"</em>"+ "<p>" ;

        HashMap<String, String> hm = new HashMap<String, String>();
//        hm.put("country", countryName);
//        hm.put("flag", flag);
        hm.put("details",details);

        return hm;
    }

    /** Process issueid tag in the xml data */
    private String readIssueid(XmlPullParser parser)
            throws IOException, XmlPullParserException {
        parser.require(XmlPullParser.START_TAG, ns, "root");
        String id = readText(parser);
        return id;
    }


    /** Getting Text from an element */
    private String readText(XmlPullParser parser)
            throws IOException, XmlPullParserException{
        String result = "";
        if(parser.next()==XmlPullParser.TEXT){
            result = parser.getText();
            parser.nextTag();
        }
        return result;
    }

    private void skip(XmlPullParser parser)
            throws XmlPullParserException, IOException {
        if (parser.getEventType() != XmlPullParser.START_TAG) {
            throw new IllegalStateException();
        }
        int depth = 1;
        while (depth != 0) {
            switch (parser.next()) {
                case XmlPullParser.END_TAG:
                    depth--;
                    break;
                case XmlPullParser.START_TAG:
                    depth++;
                    break;
            }
        }
    }
}
